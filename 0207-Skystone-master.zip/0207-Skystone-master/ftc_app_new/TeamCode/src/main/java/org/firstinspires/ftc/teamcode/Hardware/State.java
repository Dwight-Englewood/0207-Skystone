package org.firstinspires.ftc.teamcode.Hardware;

public interface State {
}