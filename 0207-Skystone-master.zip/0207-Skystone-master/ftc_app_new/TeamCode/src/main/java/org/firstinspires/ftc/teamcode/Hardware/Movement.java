package org.firstinspires.ftc.teamcode.Hardware;

public enum Movement {
    FORWARD, BACKWARD, LEFTSTRAFE, RIGHTSTRAFE, LEFTTURN, RIGHTTURN, STOP
}